import React from 'react'

// function Car1({color}) {
//     return(
//         <h2>My car is {color}!</h2>
//     );
// }

// function Car1(props){
//     const {brand,model} =props;
//     return(
//         <h1>I love my {brand} {model}!</h1>
//     )
// }

function Car1({color,model,...rest}){

    return(
        <h2>My car details {color} {model} {rest.brand} {rest.year}!</h2>
    )
}
export default Car1;

