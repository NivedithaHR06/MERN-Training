import React from 'react'

//Level 1
function Parent1({studentName}) {
    return(
        <div style={{background:"#d4f1f4",margin:"10px",padding:"10px"}}>
            <h2>Parent component</h2>
            <Child studentName={studentName}/>
        </div>
    );
}

//Level 2
function Child({studentName}) {
    return(
        <div style={{background:"#a4ebf3",margin:"10px",padding:"10px"}}>
            <h2>Child component</h2>
            <GrandChild studentName={studentName}/>
        </div>
    );
}

//Level 3
function GrandChild({studentName}) {
    return(
        <div style={{background:"lightyellow",margin:"10px",padding:"10px"}}>
            <h2>GrandChild component</h2>
            <GreatGrandChild studentName={studentName}/>
        </div>
    );
}

//Level 4
function GreatGrandChild({studentName}){
    return(
        <div style={{background:"darkgreen",color:"white",margin:"10px",padding:"10px"}}>
            <h5>GreatGrandChildren</h5>
            <p>
                👋 Hello <b>{studentName}</b>,this value was passed from the App component through 3 other components
            </p>
        </div>
    );
}

export default Parent1

