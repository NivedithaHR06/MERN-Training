import React from 'react'

function Argument(props) {
  return (
    <div>Argument{props.name} {props.phno}</div>
  )
}

export default Argument