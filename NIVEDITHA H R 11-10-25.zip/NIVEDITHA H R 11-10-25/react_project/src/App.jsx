import React from 'react'
import HTMLForms from './HTMLForms'
import ControlledForm from './ControlledForm'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './SimpleValidation'

function App() {
  return (
    <div>
      <div>App</div>
      <HTMLForms/>
      <ControlledForm/>
      <TwoWayBinding/>
      <SimpleValidation/>
    </div>
  )
}

export default App
