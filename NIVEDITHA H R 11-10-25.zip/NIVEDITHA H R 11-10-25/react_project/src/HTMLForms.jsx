import React from 'react'

function HTMLForms() {
  return (
    <div>
        <form>
            <input type="email" id="user"/>
            <br /> <br />
            <input type="password" id="user"/>
            <button>Submit</button>
        </form>
    </div>
  )
}

export default HTMLForms