import React from 'react'
class Fruit extends React.Component{
    render(){
        return <h2>FruitClass</h2>
    }
}
export default Fruit