import React, { useState } from "react";
import Modal from "./Modal";
import "./App.css";
import MathOperations from "./MathOperations";
import ErrorBoundary from "./ErrorBoundary";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showModal, setShowModal] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  return (
    <div className="app">
      <h1>React Portal Login</h1>
      <form onSubmit={handleSubmit} className="login-form">
        <input
          type="text"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button type="submit">Login</button>
      </form>

      {showModal && (
        <Modal message="Login Successfully!" onClose={closeModal} />
      )}

    <ErrorBoundary>
      <MathOperations />
    </ErrorBoundary>
    </div>
  );
}

export default App;
