import React, { useState } from "react";

function MathOperations() {
  const [num1, setNum1] = useState("");
  const [num2, setNum2] = useState("");
  const [operation, setOperation] = useState("add");
  const [result, setResult] = useState(null);

  const calculate = () => {
    const a = Number(num1);
    const b = Number(num2);

    if (isNaN(a) || isNaN(b)) {
      throw new Error("Inputs must be valid numbers!");
    }

    let res;
    switch (operation) {
      case "add":
        res = a + b;
        break;
      case "subtract":
        res = a - b;
        break;
      case "multiply":
        res = a * b;
        break;
      case "divide":
        if (b === 0) throw new Error("Division by zero is not allowed!");
        res = a / b;
        break;
      default:
        throw new Error("Invalid operation!");
    }

    setResult(res);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Math Operations</h1>

      <input
        type="text"
        placeholder="Enter first number"
        value={num1}
        onChange={(e) => setNum1(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter second number"
        value={num2}
        onChange={(e) => setNum2(e.target.value)}
      />

      <select
        value={operation}
        onChange={(e) => setOperation(e.target.value)}
      >
        <option value="add">Addition</option>
        <option value="subtract">Subtraction</option>
        <option value="multiply">Multiplication</option>
        <option value="divide">Division</option>
      </select>

      <button onClick={calculate}>Calculate</button>

      {result !== null && (
        <h3>Result: {result}</h3>
      )}
    </div>
  );
}

export default MathOperations;
