import React,{useEffect,useState} from "react";

function UsersList(){
    const[users,setUsers]=useState([]);
    const[loading,setLoading]=useState(true);
    useEffect(() => {
        async function fetchData(){
            const res=await fetch("https://jsonplaceholder.typicode.com/users");
            const data=await res.json();
            setUsers(data);
            setLoading(false);
            // setLoading(true);
        }
        fetchData();
    },[]); //fetch once

    return(
        <div>
            <h2>users List</h2>

            {/* ternary operator */}
            {loading ? (
                <p>loading...</p>
            ) : (
                <ul>
                    {/* .map() - advanced array function */}
                    {users.map((user) => (
                        <li key={user.id}>{user.name} <p key={user.id}>{user.category}</p> </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
export default UsersList;