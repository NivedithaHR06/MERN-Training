import React from 'react'

function Temperature({value}) {
  return (
    <p style={{color:value > 30 ? "red" : "green"}}>Temperature:{value}°C</p>
  );
}

export default Temperature;