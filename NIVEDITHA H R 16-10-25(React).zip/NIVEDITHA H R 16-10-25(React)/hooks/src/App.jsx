import React from 'react'
import UseEffect from './UseEffect'
import Counter from './Counter'
import Timer from './Timer'
import UsersList from './UsersList'
import Greetings from './Greetings'
import Temperature from './Temperature'

function App() {
  return (
    <div>
      <div>App</div>
      <UseEffect/>
      <Counter/>
      <Timer/>
      <UsersList/>
      <Greetings/>
      <Temperature value="40"/>
      <Temperature value="20"/>
    </div>
  )
}

export default App;