import React from 'react'

function PersonalInfo() {
  return (
    <div>This is Personal Information page</div>
  )
}

export default PersonalInfo