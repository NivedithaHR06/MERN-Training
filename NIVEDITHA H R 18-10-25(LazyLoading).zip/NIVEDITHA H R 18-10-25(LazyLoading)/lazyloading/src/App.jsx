import {lazy,Suspense,React} from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom' 
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Team from './Team';
import PersonalInfo from './PersonalInfo';

const home=lazy(() => import("./Home"));
const about=lazy(() => import("./About"));
const contact=lazy(() => import("./Contact"));

function App() {
  return (
    <Suspense>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<h1>This is Route Page</h1>} />
        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/team" element={<Team />} />
        <Route path="/personalinfo" element={<PersonalInfo />} />
      </Routes>
      </BrowserRouter>
    </Suspense>
  );
}

export default App;