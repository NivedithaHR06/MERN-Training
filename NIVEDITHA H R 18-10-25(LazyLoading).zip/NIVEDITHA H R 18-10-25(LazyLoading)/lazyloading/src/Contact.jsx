import React from 'react'

function Contact() {
  return (
    <div>This is Contact Page</div>
  )
}

export default Contact