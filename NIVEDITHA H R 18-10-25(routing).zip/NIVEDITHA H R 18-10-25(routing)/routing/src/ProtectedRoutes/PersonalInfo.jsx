import React from 'react'

function PersonalInfo() {
  return (
    <div>This is PersonalInfo</div>
  )
}

export default PersonalInfo