import React from 'react'

function Dashboard() {
  return (
    <div style={{color:"red",
      fontWeight:'bold'
    }}>This is Dashboard</div>
  )
}

export default Dashboard