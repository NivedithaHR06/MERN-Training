import React from 'react'
import { Link } from 'react-router-dom'

function Home() {
  return (
    <div style={{color:"green"}}>This is Home Page <br />
        <Link to='/login'>Login Page</Link> <br />
        <Link to='/dynamicrouting/kavya'>kavya</Link>
    </div>
  )
}

export default Home;