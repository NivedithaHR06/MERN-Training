import React from 'react'
import { useParams } from 'react-router-dom'

function DynamicRouting() {
  const {id}=useParams();
  return <h2 style={{color:"yellowgreen"}}>Good Morning:{id}</h2>;
}

export default DynamicRouting;