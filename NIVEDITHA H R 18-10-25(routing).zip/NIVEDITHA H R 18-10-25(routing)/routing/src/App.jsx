import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Home from './ProtectedRoutes/Home';
import Dashboard from './ProtectedRoutes/Dashboard';
import Login from './ProtectedRoutes/Login';
import Protectedroutes from './ProtectedRoutes/Protectedroutes';
import DynamicRouting from './DynamicRouting';

function App() {
  return (
    <div>
      <h1 style={{ color: 'violet',
        backgroundColor:'lightgoldenrodyellow'
       }}>React Protected Routes Example</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route 
            path="/dashboard" 
            element={
              <Protectedroutes>
                <Dashboard />
              </Protectedroutes>
            } 
          />
          <Route path="/dynamicrouting/:id" element={<DynamicRouting/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
